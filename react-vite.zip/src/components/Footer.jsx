export const Footer = () => {
    return (
        <footer className="absolute bottom-0 w-full h-[70px] bg-slate-500 items-center flex justify-between">
            Footer
            <button>Dil Degistir</button>
        </footer>
    )
}
