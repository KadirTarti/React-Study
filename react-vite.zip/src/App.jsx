function App() {

    return (
        <div className='flex flex-col h-screen justify-between'>
           content
        </div>
    )
}

export default App
